function validiteForm(){
    var x = document.forms["myForm"]["First Name"].value;
    var a = document.forms["myForm"]["Last Name"].value;
    var y = document.forms["myForm"]["Email"].value;
    var z = document.forms["myForm"]["Telephone"].value;

    if(x == ""){
        alert("First Name must be filled");
        return false;
    } else if(a ==""){
        alert("Last Name must be filled");
        return false;
    }else if(y ==""){
        alert("Emial must be filled");
        return false;
    } else if(z == ""){
        alert("Telephone Number must be filled");
        return false;
    }
    else{
        alert("Thank you for your contact infomation");
        return true;
    }
}