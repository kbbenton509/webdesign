function sqrt_cal(x){
    temp = parseInt(x);
    Calc.Answer.value = 'Answer of sqrt(' + x + ') = ';
    Calc.input.value = Math.sqrt(temp);
}

function sin_cal(x){
    temp = parseInt(x);
    Calc.Answer.value = 'Answer of sin(' + x + ') = ';
    Calc.input.value = Math.sin(temp * Math.PI / 180);

}

function cos_cal(x){
    temp = parseInt(x);
    Calc.Answer.value = 'Answer of cos(' + x + ') = ';
    Calc.input.value = Math.cos(temp * Math.PI / 180);
}

function tan_cal(x){
    temp = parseInt(x);
    Calc.Answer.value = 'Answer of tan(' + x + ') = ';
    Calc.input.value = Math.tan(temp * Math.PI / 180);
}

function ln_cal(x){
    temp = parseInt(x);
    Calc.Answer.value = 'Answer of ln(' + x + ') = ';
    Calc.input.value = Math.log(temp);
}

function log_cal(x){
    temp = parseInt(x);
    Calc.Answer.value = 'Answer of ln(' + x + ') = ';
    Calc.input.value = Math.log10(temp);
}

function fact_c(x){
    factvar=parseInt(x);
    if (x == 0 || x == 1){
        return 0;
    }
    else{
        for (i=1;i<=parseInt(x);i++){
        factvar=factvar*i;
        }
        return factvar;
    }
   
}

function power_cal(x){
    var temp_string = x.toString();
    var temp_string1 = temp_string.split(",");
    temp = parseInt(temp_string1[0]);
    temp1 = parseInt(temp_string1[1]);
    Calc.Answer.value = 'Answer of ' + temp + '^' + temp1 + ' =';
    Calc.input.value = Math.pow(temp, temp1);
}

function EXP_cal(x){
    var temp_string = x.toString();
    var temp_string1 = temp_string.split(",");
    temp = parseInt(temp_string1[0]);
    temp1 = parseInt(temp_string1[1]);
    Calc.Answer.value = 'Answer of ' + temp + '* 10^' + temp1 + ' =';
    Calc.input.value = E(temp, temp1);
}

function E(x,y){
    EXPval = 1;
    EXPval = x * Math.pow(10, y);
    return EXPval;
}