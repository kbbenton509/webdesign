<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="./Style/Style.css" />
    <title> Toyota</title>
</head>
<body>
    <a href="./index.html">
        <div class="parentdiv"> 
	        <img src="./images/Images/toyota-banner.png" class="bannercar"/>
        </div>
    </a>
</body>
</html>
