<!DOCTYPE HTML>
<html>
<style>
table, th, td {
    border: 1px solid black;
}
</style>

<body>


<?php

$month = "";
$year = "";
$user = "";
$units = "";
$monthDB = $yearDB = $userDB = $unitsDB = 0;

   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
	   	if (empty($_POST["uname"])) {
	    $userDB = 0;
	  } else {
	    $user = test_input($_POST["uname"]);
	    $userDB = 1;
	  }
	  
	  if (empty($_POST["month"])) {
	    $monthDB = 0;
	  } else {
	    $month = test_input($_POST["month"]);
	    $monthDB = 1;
	  }

	  if (empty($_POST["year"])) {
	    $yearDB = 0;
	  } else {
	    $year = test_input($_POST["year"]);
	    $yearDB = 1;
	  }

	  if (empty($_POST["units"])) {
	    $unitsDB = 0;
	  } else {
	    $units = test_input($_POST["units"]);
	    $unitsDB = 1;
	  }
	}

	if( ($userDB == 1) && ($monthDB==1) && ($yearDB==1) && ($unitsDB==1) )
	{
		$servername = 'localhost';
		$DBusername = 'root';
		$DBpassword = '';
		$dbname = "Electric";

		// Create connection
		$conn = new mysqli($servername, $DBusername, $DBpassword, $dbname);
		// Check connection
		if ($conn->connect_error) {
		    die("Connection failed: " . $conn->connect_error);
		} 
		
		$sql = "INSERT INTO `Eusage` (`username`, `month`, `year`, `units`) VALUES ('$user', '$month', '$year', '$units')";
		if ($conn->query($sql) === TRUE) {
		echo "Your entry has been successfully inserted";
		} else {
		    echo "Error entering into the database: " . $conn->error;
		}

$conn->close();
	}

session_start();
if(!isset($_SESSION["login_user"]))
{
	header('URL = index.php');
}else
{
	$servername = 'localhost';
	$DBusername = 'root';
	$DBpassword = '';
	$dbname = "Electric";

	// Create connection
	$conn = new mysqli($servername, $DBusername, $DBpassword, $dbname);
	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	} 
	
	$user =  $_SESSION['login_user'];
	$sql = "SELECT * FROM `User` WHERE `username` LIKE '$user'";
	$result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$role = $row["role"];
	echo "<h3> Welcome " . $row["firstname"]. "</h3>";
	?>
	<form action="index.php">
	<input type="submit" value="logout" >
	</form>
	<?php 
}


	if($role == 0)
	{
		$conn = new mysqli($servername, $DBusername, $DBpassword, $dbname);
		// Check connection
		if ($conn->connect_error) {
	   		die("Connection failed: " . $conn->connect_error);
		}
		$sql = "SELECT * FROM `Eusage` WHERE `username` LIKE '$user'";
		$result = $conn->query($sql);

		echo "
		<h3>Here is your useage table</h3>
		<table style='width:50%''>
		<tr>
			<th>Month</th>
			<th>Year</th>
			<th>Units</th>
		</tr>
		";
		while($row2 = $result->fetch_assoc()){
			echo"
			<tr>
			<td>".$row2["month"]."</td>
			<td>".$row2["year"]."</td>
			<td>".$row2["units"]."</td>
			</tr>";
		}
		echo"</table>";
	}
	else
	{
		?>

		<form action="" method="post">
		
		<table>
			<h3> Submit meter reading</h3>
			<tr>
				<td>
					<label> User Name: </label>
				</td>
				<td>
					<input type="text" name="uname">
				</td>
			</tr>
			<tr>
				<td>
					<label> Month </label>
				</td>
				<td>
					<input type="text" name="month">
				</td>
			</tr>

			<tr>
				<td>
					<label> Year </label>
				</td>
				<td>
					<input type="text" name="year">
				</td>
			</tr>

			<tr>
				<td>
					<label> Units </label>
				</td>
				<td>
					<input type="text" name="units">
				</td>
			</tr>

			<tr>
				<td>
					<input type="submit" name="submit" value="Submit">
				</td>
			</tr>
		</table>
	</form>
	<?php
	}


	function test_input($data) {
	  $data = trim($data);
	  $data = stripslashes($data);
	  $data = htmlspecialchars($data);
	  return $data;
	}
?>
</body>
</html>